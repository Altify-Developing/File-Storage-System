$(document).ready(function() {
  let origin = location.origin;
  if (window.location.href.indexOf("lazy") > -1) {
		setTimeout(refre, 100);
    function refre() {
			location.reload();
		}
  }
});
